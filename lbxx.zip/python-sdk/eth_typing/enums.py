class ForkName:
    Frontier = 'Frontier'
    Homestead = 'Homestead'
    EIP150 = 'EIP150'
    EIP158 = 'EIP158'
    Byzantium = 'Byzantium'
    Constantinople = 'Constantinople'
    Metropolis = 'Metropolis'
