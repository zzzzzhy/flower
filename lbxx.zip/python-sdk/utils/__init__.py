import pkg_resources
import sys
import warnings