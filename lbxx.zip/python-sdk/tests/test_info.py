

import platform
print("python_version", platform.python_version())
print("java_ver", platform.java_ver())
print("libc_ver", platform.libc_ver())
print("machine", platform.machine())
print("mac_ver", platform.mac_ver())
print("architecture", platform.architecture())
print("processor", platform.processor())
print("python_branch", platform.python_branch())
print("python_compiler", platform.python_compiler())
print("python_version_tuple", platform.python_version_tuple())
print("system", platform.system())
print("uname", platform.uname())
print("version", platform.version())
print("python_implementation", platform.python_implementation())


