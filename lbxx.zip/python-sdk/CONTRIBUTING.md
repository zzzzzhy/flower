# Development

To start development you should begin by cloning the repo.

```bash
$ git clone [repo_url]
```
